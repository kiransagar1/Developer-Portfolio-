---
name: Bug report
about: Report a problem with a template
labels: bug
---

**Template**
Classic / Terminal / Case Study

**What happened**

**What you expected**

**Browser and device**

**Screenshot (optional)**
